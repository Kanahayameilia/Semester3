/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.anaya1;

/**
 *
 * @author acer
 */
public class Anaya1 {

    public static void main(String[] args) {
        System.out.println("Nama    :   Evangeliosanaya Eimili");
        System.out.println("NPM     :   2420506021");
        System.out.println("Alamat  :   Cemara 7, Jl.Buton gg anggrek 4");
        System.out.println("No_HP   :   085838349936");

    }
}
